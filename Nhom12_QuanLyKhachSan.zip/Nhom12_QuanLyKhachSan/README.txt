AUTUMN HOTEL - QUẢN LÝ KHÁCH SẠN (WinForms + SQL Server)
=========================================================
Nhóm: [điền tên nhóm]            Thành viên: [điền họ tên - MSSV]
Học phần: Lập trình Windows - Đồ án cuối kỳ (MVP bàn giao)

1. CẤU TRÚC GÓI NỘP
-------------------
SourceCode/        Mã nguồn: QuanLyKhachSan (ứng dụng WinForms, mô hình MVP),
                   QuanLyKhachSan.Web (cổng web tra cứu qua mã QR),
                   QuanLyKhachSan.Tests (kiểm thử tự động), QuanLyKhachSan.sln,
                   README.md (hướng dẫn chi tiết), docs/ (tài liệu yêu cầu, thiết kế, kịch bản).
Database/          01_CreateDatabase.sql  - tạo CSDL, bảng, ràng buộc, stored procedure
                   02_InsertSampleData.sql - dữ liệu mẫu và tài khoản demo
                   KiemThu.sql            - 34 ca kiểm thử CSDL (tùy chọn)
                   QuanLyKhachSan.bak     - bản sao lưu (khôi phục nhanh, cần SQL Server 2022 trở lên)
Report/            BaoCao.pdf (báo cáo), LaTeX/ (mã nguồn LaTeX và hình để biên dịch lại)
Screenshots/       Ảnh chụp màn hình các chức năng chính
TestCases/         TestCase.xlsx - liệt kê toàn bộ ca kiểm thử (TongHop, KiemThuTuDong,
                   CSDL_Build, GiaoDien_Web, HuongDan)

2. YÊU CẦU MÔI TRƯỜNG
---------------------
- Windows 10/11.
- Visual Studio 2026 (18.0 trở lên) với workload ".NET desktop development"
  (project target net10.0; Visual Studio 2022 không build được), hoặc .NET 10 SDK.
- SQL Server Express / LocalDB / SQL Server có quyền tạo database.

3. CÀI ĐẶT NHANH
----------------
Bước 1 - Tạo CSDL (chọn một trong hai cách):
  a) Chạy lần lượt Database/01_CreateDatabase.sql rồi 02_InsertSampleData.sql
     (SSMS -> Execute, hoặc:
       sqlcmd -S localhost -E -C -b -f 65001 -i Database\01_CreateDatabase.sql
       sqlcmd -S localhost -E -C -b -f 65001 -i Database\02_InsertSampleData.sql )
  b) Khôi phục Database/QuanLyKhachSan.bak bằng SSMS (Restore Database), cần SQL Server 2022+.
Bước 2 - Chuỗi kết nối: sửa SourceCode/QuanLyKhachSan/appsettings.json (khóa
  ConnectionStrings:KhachSan) nếu SQL Server của bạn không phải instance mặc định "localhost".
Bước 3 - Mở SourceCode/QuanLyKhachSan.sln bằng Visual Studio, đặt QuanLyKhachSan làm
  Startup Project, nhấn F5.
Bước 4 (tùy chọn) - Cổng web tra cứu:
  dotnet run --project SourceCode\QuanLyKhachSan.Web\QuanLyKhachSan.Web.csproj --urls http://localhost:5080

4. TÀI KHOẢN DEMO
-----------------
  Lễ tân : letan  / Admin@123
  Quản lý: admin  / Admin@123
(Chỉ dùng để chấm bài; phải đổi mật khẩu khi triển khai thật. Sai mật khẩu 5 lần sẽ bị khóa 30 giây.)

5. KỊCH BẢN DEMO 7 PHÚT (xem chi tiết SourceCode/docs/09_HuongDan_Demo.md)
-------------------------------------------------------------------------
  1. Giới thiệu bài toán và người dùng mục tiêu
  2. Đăng nhập bằng tài khoản demo (letan)
  3. Luồng nghiệp vụ chính: Đặt phòng (F2) -> Nhận phòng (F3) -> Ghi dịch vụ (F4)
     -> Trả phòng (F6), giảm giá trên 10% cần Quản lý duyệt, in hóa đơn
  4. Thêm / sửa / ngừng sử dụng / tìm kiếm (Khách hàng, Hóa đơn, Khách đang ở)
  5. Báo cáo doanh thu, công suất, in và xuất CSV (đăng nhập admin)
  6. Database và kiến trúc mã nguồn (Models - Repositories - Services - Presenters - Views)
  7. Hạn chế và hướng phát triển

6. KIỂM THỬ
-----------
- Chạy tự động: dotnet run --project SourceCode\QuanLyKhachSan.Tests
  (208 ca; thoát mã 1 nếu có ca lỗi). Kết quả gần nhất trên GitHub Actions: 208/208 đạt.
- Kịch bản SQL: Database/KiemThu.sql (34 ca, 34/34 đạt trên SQL Server 2022).
- TestCases/TestCase.xlsx: 274 ca = 208 tự động + 39 CSDL/build + 27 kịch bản giao diện và
  web chạy thủ công (cột kết quả thực tế của 27 ca này do người thử điền).

7. LƯU Ý
--------
- Báo cáo Report/BaoCao.pdf biên dịch bằng XeLaTeX; bản kèm theo dùng phông Liberation Serif
  thay Times New Roman. Muốn dùng đúng Times New Roman: biên dịch lại Report/LaTeX/bao_cao_full.tex
  bằng xelatex trên máy có phông này (chạy 2-3 lần để cập nhật mục lục).
- Cổng web chỉ đọc, không hiển thị thông tin khách; địa chỉ gốc của mã QR đặt ở khóa Web:BaseUrl
  trong appsettings.json.
- Hạn chế đã biết: chưa có thanh toán trực tuyến, đặt phòng qua web, gửi email/tin nhắn; khóa
  đăng nhập chỉ lưu trong bộ nhớ phiên làm việc; thao tác giao diện WinForms kiểm thử thủ công.
